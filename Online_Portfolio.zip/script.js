document.addEventListener('DOMContentLoaded', function() {
    const taskForm = document.getElementById('task-form');
    const taskInput = document.getElementById('task-input');
    const taskList = document.getElementById('task-list');
    const clearBtn = document.getElementById('clear-tasks');
    const hideCompletedCheckbox = document.getElementById('hide-completed');

    // Load tasks from localStorage
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

    // Function to display tasks
    function displayTasks() {
        taskList.innerHTML = '';
        tasks.forEach(function(task, index) {
            const li = document.createElement('li');
            li.innerHTML = `
                <input type="checkbox" ${task.completed ? 'checked' : ''} data-index="${index}">
                <span class="${task.completed ? 'completed' : ''}">${task.name}</span>
                <button class="edit" data-index="${index}">Edit</button>
                <button class="delete" data-index="${index}">Delete</button>
            `;
            taskList.appendChild(li);
        });
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    // Add new task
    taskForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const taskName = taskInput.value.trim();
        if (taskName !== '') {
            tasks.push({ name: taskName, completed: false });
            displayTasks();
            taskInput.value = '';
        }
    });

    // Toggle task completion
    taskList.addEventListener('change', function(e) {
        if (e.target.matches('input[type="checkbox"]')) {
            const index = e.target.getAttribute('data-index');
            tasks[index].completed = !tasks[index].completed;
            displayTasks();
        }
    });

    // Delete or edit task
    taskList.addEventListener('click', function(e) {
        if (e.target.classList.contains('delete')) {
            const index = e.target.getAttribute('data-index');
            tasks.splice(index, 1);
            displayTasks();
        }
        if (e.target.classList.contains('edit')) {
            const index = e.target.getAttribute('data-index');
            const newName = prompt('Edit Task:', tasks[index].name);
            if (newName !== null) {
                tasks[index].name = newName.trim();
                displayTasks();
            }
        }
    });

    // Clear all tasks
    clearBtn.addEventListener('click', function() {
        tasks = [];
        displayTasks();
    });

    // Toggle hide completed tasks
    hideCompletedCheckbox.addEventListener('change', function() {
        const isChecked = hideCompletedCheckbox.checked;
        const filteredTasks = isChecked ? tasks.filter(task => !task.completed) : tasks;
        taskList.innerHTML = '';
        filteredTasks.forEach(function(task, index) {
            const li = document.createElement('li');
            li.innerHTML = `
                <input type="checkbox" ${task.completed ? 'checked' : ''} data-index="${index}">
                <span class="${task.completed ? 'completed' : ''}">${task.name}</span>
                <button class="edit" data-index="${index}">Edit</button>
                <button class="delete" data-index="${index}">Delete</button>
            `;
            taskList.appendChild(li);
        });
    });

    // Initial display of tasks
    displayTasks();
});

